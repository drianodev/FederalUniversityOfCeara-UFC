#Em cada função abaixo programe o que está definido na explicação e docstring.
#Se seu código executar e imprimir no terminal a frase abaixo é porque passou em
#todos os testes.
#"Process finished with exit code 0"

#Questão 1: String, For
#A questão abaixo pede para você encriptar uma mensagem.
#Encriptar é esconder a mensagem original em outra.
#O procedimento para encriptar a mensagem 'hello world' é:
# 'h' ocorre na posição 21 do código do teste, que corresponde
# a letra 'u' no alfabeto regular disponibilizado na descrição.
# 'e' ocorre na posição 24 do código do teste, que corresponde
# a letra 'x' no alfabeto regular disponibilizado na descrição.
# Esse procedimento ocorre para toda letra da mensagem.
def encripta(mensagem, codigo):
    '''(str, str) -> str
    Retorne a mensagem criptografada usando o código fornecido.
    O código é uma ordem do alfabeto mais os caracteres espaço e '.'.
    A posição de cada caractere na string de código fornece o
    índice do caractere de substituição no alfabeto regular
    'abcdefghijklmnopqrstuvwxyz .'
    >>> encripta('hello world', '. zyxwvutsrqponmlkjihgfedcba')
    'uxqqnbfnkqy'
    >>> encripta('mensagem', '. zyxwvutsrqponmlkjihgfedcba')
    'pxoj.vxp'
    >>> encripta('', '. zyxwvutsrqponmlkjihgfedcba')
    ''
    '''

#Questão 2: Lista
def string_lista(L):
    '''(list de str) -> list de list
    A função string_lista recebe uma lista L de strings com o formato:
    'nome, nota, nota, nota, ...'. Ela deve retornar uma lista de listas,
    onde cada lista interna tem o formato: [nome, nota, nota, nota, ...].
    Nome é uma string e nota é um float.

    >>> string_lista(['Ana, 50, 90, 80', 'João, 60, 70', 'Carla, 98.5, 100, 95.5, 98'])
    [['Ana', 50.0, 90.0, 80.0], ['João', 60.0, 70.0], ['Carla', 98.5, 100.0, 95.5, 98.0]]
    >>> string_lista(['Ana, 50, 90, 80'])
    [['Ana', 50.0, 90.0, 80.0]]
    >>> string_lista(['Ana, 50, 90, 80', 'João, 60, 70', 'Carla, 98.5'])
    [['Ana', 50.0, 90.0, 80.0], ['João', 60.0, 70.0], ['Carla', 98.5]]
    '''

#Questão 3: Dicionário
#Considere um dicionário onde cada chave é uma tupla de 3 elementos contendo o
#nome de uma equipe esportiva, sua cidade e seu esporte, e cada valor é o
#número de vitórias dessa equipe. Por exemplo:
#d = {(’Fortaleza’, ’Fortaleza’, ’futebol’): 10,
#     (’Carcará’, ’Fortaleza’, ’basquetebol’): 15,
#     (’Corinthians’, ’São Paulo’, ’futebol’): 9,
#     (’Sesi’, ’Bauru’, ’vôlei’): 3}
#O cabeçalho da função obtem_vitorias_por_categoria aparece abaixo. Possui dois parâmetros:
# - um dicionário como o acima.
# - a categoria, que é uma string: 'nome', 'cidade' ou 'esporte'.
#obtem_vitorias_por_categoria retorna um novo dicionário baseado no dicionário
#passado por parâmetro, no qual as chaves são os nomes, cidades ou esportes
#(conforme especificado por categoria) e os valores são o número total de vitórias
#associadas a cada chave.
def obtem_vitorias_por_categoria(time_para_vitoria: dict, categoria: str):
    '''
    Para cada tupla chave em time_para_vitoria, busque a entrada correspondente à categoria.
    Essas entradas devem ser chaves do dicionário a ser retornado. O valor dessa chave é a
    soma de todos os valores onde a entrada apareceu em time_para_vitoria.

    >>> obtem_vitorias_por_categoria({('Fortaleza', 'Fortaleza', 'futebol'): 10,('Carcará', 'Fortaleza', 'basquetebol'): 15,('Corinthians', 'São Paulo', 'futebol'): 9,('Sesi', 'Bauru', 'vôlei'): 3}, 'esporte')
    {'futebol': 19, 'basquetebol': 15, 'vôlei': 3}
    >>> obtem_vitorias_por_categoria({('Fortaleza', 'Fortaleza', 'futebol'): 10,('Carcará', 'Fortaleza', 'basquetebol'): 15,('Corinthians', 'São Paulo', 'futebol'): 9,('Sesi', 'Bauru', 'vôlei'): 3}, 'nome')
    {'Fortaleza': 10, 'Carcará': 15, 'Corinthians': 9, 'Sesi': 3}
    >>> obtem_vitorias_por_categoria({('Fortaleza', 'Fortaleza', 'futebol'): 10,('Carcará', 'Fortaleza', 'basquetebol'): 15,('Corinthians', 'São Paulo', 'futebol'): 9,('Sesi', 'Bauru', 'vôlei'): 3}, 'cidade')
    {'Fortaleza': 25, 'São Paulo': 9, 'Bauru': 3}
    '''

#Questão 4: arquivo
#Você pode presumir que todas as funções estão formatadas de forma exata e correta:
#Um espaço após o def, nenhum espaço antes do (.
def nome_funcao(nome_arquivo):
    """
    A função nome_funcao recebe a string nome_arquivo, que é o nome de um arquivo código fonte, 
    como parâmetro e retorna uma lista contendo todo nome de função encontrado no arquivo.
    Caso o arquivo não tenha função definida, a lista retornada é vazia.
    >>> nome_funcao('respostas_p2.py')
    ['pares_e_impares', 'primeiro_float', 'somente_inteiro', 'artilheiros_temporada']
    >>> nome_funcao('condicionais.py')
    ['categoria_tempestade', 'mensagem_categoria', 'aviso']
    >>> nome_funcao('vazio.py')
    []
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

