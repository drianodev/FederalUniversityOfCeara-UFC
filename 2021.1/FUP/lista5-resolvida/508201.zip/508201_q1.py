n = int(input("Digite o número: "))

for i in range(n , n+1):
  for j in range(i, i+1):
    print('+*****')
    print('*+****')
    print('**+***')
    print('***+**')
    print('****+*')
    print('*****+')
  print()

